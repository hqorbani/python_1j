name = input("tell me your name please: ")
print("welcome" , name)
age = input("how old are you? ")
country = input("where are you from? ")

print("so dear" ,name , "you are from" , country , "and you are", age , "years old.")
agree = input("Do you apply it? (yes/no) ")
